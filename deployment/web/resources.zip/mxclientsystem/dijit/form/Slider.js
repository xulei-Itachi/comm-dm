//>>built
define("dijit/form/Slider",["dojo/_base/kernel","./HorizontalSlider","./VerticalSlider","./HorizontalRule","./VerticalRule","./HorizontalRuleLabels","./VerticalRuleLabels"],function(_1){
_1.deprecated("Call require() for HorizontalSlider / VerticalRule, explicitly rather than 'dijit.form.Slider' itself","","2.0");
});
