//>>built
define("dijit/form/nls/de/ComboBox",({previousMessage:"Vorherige Auswahl",nextMessage:"Weitere Auswahlmöglichkeiten"}));
