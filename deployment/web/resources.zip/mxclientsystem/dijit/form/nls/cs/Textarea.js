//>>built
define("dijit/form/nls/cs/Textarea",({iframeEditTitle:"oblast úprav",iframeFocusTitle:"rámec oblasti úprav"}));
