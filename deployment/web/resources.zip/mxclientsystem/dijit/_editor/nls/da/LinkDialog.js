//>>built
define("dijit/_editor/nls/da/LinkDialog",({createLinkTitle:"Linkegenskaber",insertImageTitle:"Billedegenskaber",url:"URL:",text:"Beskrivelse:",target:"Mål:",set:"Definér",currentWindow:"Aktuelt vindue",parentWindow:"Overordnet vindue",topWindow:"Øverste vindue",newWindow:"Nyt vindue"}));
