//>>built
define("dijit/_editor/nls/ru/LinkDialog",({createLinkTitle:"Свойства ссылки",insertImageTitle:"Свойства изображения",url:"URL:",text:"Описание:",target:"Целевой объект:",set:"Задать",currentWindow:"Текущее окно",parentWindow:"Родительское окно",topWindow:"Верхнее окно",newWindow:"Новое окно"}));
